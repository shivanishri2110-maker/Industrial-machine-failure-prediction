# Industrial Machine Failure Prediction — Colab Quickstart
# 1) Upload your assigned CSV as /content/machine_failure_dataset.csv
# 2) Set TARGET and FEATURES below
# 3) Run all cells

!pip -q install pandas numpy scikit-learn joblib matplotlib streamlit

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, roc_auc_score

DATA = "/content/machine_failure_dataset.csv"
TARGET = "machine_failure"
FEATURES = ["temperature", "vibration", "pressure", "runtime", "maintenance_gap"]

df = pd.read_csv(DATA)
X, y = df[FEATURES], df[TARGET]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

model = Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("scaler", StandardScaler()),
    ("classifier", LogisticRegression(
        max_iter=2000, class_weight="balanced", random_state=42
    ))
])

model.fit(X_train, y_train)
pred = model.predict(X_test)
prob = model.predict_proba(X_test)[:,1]

print(classification_report(y_test, pred, digits=4))
print("ROC-AUC:", roc_auc_score(y_test, prob))
