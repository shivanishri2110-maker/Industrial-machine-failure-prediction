# Industrial Machine Failure Prediction

## Track 1 Final Capstone — Problem 21

**Goal:** Predict whether an industrial machine is likely to experience a failure within a defined operating window using temperature, vibration, pressure, runtime, and maintenance-gap indicators.

### Important dataset note
The internship brief shown in the supplied image specifies the expected inputs but **does not include the assigned dataset itself**. To make an immediately reproducible prototype, this submission package contains a clearly labelled synthetic dataset generated from the five expected inputs. It is **not claimed to be the internship's hidden/assigned dataset**.

If your internship provides a CSV dataset, replace:

`data/machine_failure_dataset.csv`

with the assigned file, update `FEATURES` and the target column in `train_model.py`, run the training script, and regenerate the results before submitting.

### Included
- `data/machine_failure_dataset.csv` — reproducible demo dataset
- `train_model.py` — preprocessing, model comparison, evaluation, model export
- `app.py` — Streamlit prediction prototype
- `models/machine_failure_model.joblib` — trained demo model
- `models/metrics.json` — evaluation metrics
- `figures/` — EDA/evaluation plots
- `reports/Final_Report.docx` — report
- `VIDEO_DEMO_SCRIPT.md` — 45–60 second demo script
- `PROFILE_LINKS_TEMPLATE.txt` — submission-form checklist
- `requirements.txt` — dependencies

## Run locally

```bash
pip install -r requirements.txt
python train_model.py
streamlit run app.py
```

## Model choice

The package compares Logistic Regression and Decision Tree. Logistic Regression is selected as the foundational model because it is interpretable, lightweight, reproducible, and supports probability-based risk communication. Class weighting is used because failure cases are less frequent than normal cases.

## Reproducibility

- Random seed: 42
- Train/test split: 80/20
- Stratification: enabled
- Missing-value handling: median imputation
- Logistic Regression preprocessing: standardization
- Evaluation: Accuracy, Precision, Recall, F1, ROC-AUC, confusion matrix

## Dataset source for the brief

If your mentor intended the public UCI AI4I predictive-maintenance dataset instead, use the UCI repository page and cite it explicitly:

https://archive.ics.uci.edu/dataset/601/ai4i

Do not replace your assigned dataset with this public dataset unless your internship instructions allow it.
