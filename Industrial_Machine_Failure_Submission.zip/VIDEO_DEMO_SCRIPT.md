# 45–60 Second Video Demo Script

1. **0–5 sec:** Show the project title in the README/PPT.
   Say: “This project predicts whether an industrial machine is likely to fail from operating and maintenance indicators.”

2. **5–15 sec:** Open the dataset/EDA plot.
   Say: “The prototype investigates temperature, vibration, pressure, runtime and maintenance gap, including class balance and data quality.”

3. **15–25 sec:** Open the training output / metrics.
   Say: “We compare foundational classification models and evaluate them using accuracy, precision, recall, F1-score and ROC-AUC.”

4. **25–45 sec:** Run Streamlit and enter a high-risk combination.
   Suggested demo values:
   - Temperature: 95
   - Vibration: 6
   - Pressure: 8
   - Runtime: 2200
   - Maintenance gap: 220
   Click **Predict Failure Risk**.

5. **45–55 sec:** Show the predicted probability and warning.
   Say: “The application converts the trained model output into an interpretable failure-risk prediction for a new observation.”

6. **55–60 sec:** Show README/report.
   Say: “The project is reproducible using open-source Python tools and is designed as a lightweight prototype.”

**Recording tip:** Use your laptop screen recorder. Keep the video under one minute and make sure the terminal/model output and Streamlit prediction are readable.
