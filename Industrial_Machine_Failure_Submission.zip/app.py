import streamlit as st
from pathlib import Path
import joblib
import pandas as pd

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "models" / "machine_failure_model.joblib"

st.set_page_config(page_title="Industrial Machine Failure Prediction", page_icon="⚙️")
st.title("⚙️ Industrial Machine Failure Prediction")
st.caption("Zero-cost ML prototype for binary failure-risk classification")

model = joblib.load(MODEL_PATH)

st.sidebar.header("Machine Inputs")
temperature = st.sidebar.number_input("Temperature", min_value=35.0, max_value=115.0, value=70.0, step=0.5)
vibration = st.sidebar.number_input("Vibration", min_value=0.0, max_value=10.0, value=3.0, step=0.1)
pressure = st.sidebar.number_input("Pressure", min_value=2.0, max_value=10.0, value=6.0, step=0.1)
runtime = st.sidebar.number_input("Runtime (hours)", min_value=50.0, max_value=3000.0, value=600.0, step=10.0)
maintenance_gap = st.sidebar.number_input("Maintenance gap (hours)", min_value=0.0, max_value=500.0, value=50.0, step=5.0)

row = pd.DataFrame([{
    "temperature": temperature,
    "vibration": vibration,
    "pressure": pressure,
    "runtime": runtime,
    "maintenance_gap": maintenance_gap
}])

if st.button("Predict Failure Risk", type="primary"):
    probability = float(model.predict_proba(row)[0, 1])
    prediction = int(probability >= 0.5)

    st.subheader("Prediction")
    if prediction:
        st.error("⚠️ FAILURE RISK DETECTED")
    else:
        st.success("✅ NO FAILURE PREDICTED")

    st.metric("Estimated failure probability", f"{probability:.1%}")
    st.progress(min(probability, 1.0))

    if probability >= 0.50:
        st.warning("Recommended action: inspect the machine and consider preventive maintenance.")
    elif probability >= 0.25:
        st.info("Moderate risk: continue monitoring sensor and maintenance indicators.")
    else:
        st.info("Low predicted risk for the supplied operating conditions.")

st.divider()
st.markdown("### Project workflow")
st.write("Input → preprocessing → Logistic Regression → probability → binary risk decision")
st.caption("This is a prototype and should not be used as a safety-critical maintenance decision system.")
