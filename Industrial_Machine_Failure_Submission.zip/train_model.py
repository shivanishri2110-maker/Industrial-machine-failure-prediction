"""
Industrial Machine Failure Prediction
Train, evaluate, and save a reproducible baseline model.

Run:
    python train_model.py
"""

from pathlib import Path
import json
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
)

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "machine_failure_dataset.csv"
MODEL_DIR = ROOT / "models"
FEATURES = ["temperature", "vibration", "pressure", "runtime", "maintenance_gap"]

df = pd.read_csv(DATA)
X = df[FEATURES]
y = df["machine_failure"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

models = {
    "Logistic Regression": Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
        ("classifier", LogisticRegression(
            max_iter=2000, class_weight="balanced", random_state=42
        ))
    ]),
    "Decision Tree": Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("classifier", DecisionTreeClassifier(
            max_depth=6, min_samples_leaf=8,
            class_weight="balanced", random_state=42
        ))
    ])
}

results = {}
for name, model in models.items():
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    prob = model.predict_proba(X_test)[:, 1]
    results[name] = {
        "accuracy": accuracy_score(y_test, pred),
        "precision": precision_score(y_test, pred, zero_division=0),
        "recall": recall_score(y_test, pred, zero_division=0),
        "f1": f1_score(y_test, pred, zero_division=0),
        "roc_auc": roc_auc_score(y_test, prob),
    }

selected = models["Logistic Regression"]
joblib.dump(selected, MODEL_DIR / "machine_failure_model.joblib")

with open(MODEL_DIR / "metrics.json", "w") as f:
    json.dump(results, f, indent=2)

print(pd.DataFrame(results).T.round(4))
print("\nSaved:", MODEL_DIR / "machine_failure_model.joblib")
